﻿namespace Random_Song;

class Program
{   
    static void Main(string[] args)
    {   
        string[] songs = {
            "WARSAW: Jack Harlow",
            "Another Late Night (feat. Lil Yachty): Drake",
            "500 Benz: Joey Bada$$",
            "C Carter: Cordae",
            "No Role Modelz: J. Cole",
            "8am in Charolette: Drake",
            "Do Not Disturb: Drake",
            "This My Life: Lil Tecca",
            "500lbs: Lil Tecca",
            "Interstellar (feat. Lil Uzi Vert): NAV"
        };

        bool running = true;
        int playlistCnt = 0, playlistLength;
        List<string> newPlaylist = new List<string>();
        Random rd = new Random();


        Console.WriteLine("Random Music Playlist\n----------------------");

        while (running) {
            newPlaylist.Clear();

            while (true) {
                Console.WriteLine("Enter the number of songs to add: ");
                playlistLength = Convert.ToInt32(Console.ReadLine());
                if (1<=playlistLength && playlistLength<=10) {
                    for (int n=0; n<playlistLength; n++) {
                        int rn = rd.Next(0, 10);
                        string song = songs[rn];
                        if (!newPlaylist.Contains(song)) {
                            newPlaylist.Add(song);
                        } else {
                            n--;
                        }  
                    }
                    playlistCnt++;
                    break;
                } else {
                    Console.WriteLine("ERROR: Please enter a number between 1-10");
                }
            }
            


            Console.WriteLine("Playlist " + playlistCnt + "\n-----------");
            foreach (string song in newPlaylist) {
                Console.WriteLine(song);
            }

            


            Console.WriteLine("Would you like to continue? (y/n) ");
            if (Console.ReadLine().ToUpper() == "N") {
                running = false;
            } 
        
        }
    }
}
