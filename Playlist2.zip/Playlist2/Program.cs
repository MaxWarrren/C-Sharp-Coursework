﻿namespace Random_Song;

class Program
{       
    static string[] loadSongs(string directory) {
        string songData = File.ReadAllText(directory);
        return songData.Split("\n");
    }

    static void savePlaylist(List<string> playlist, string file) {
        foreach (string song in playlist) {
            File.AppendAllText(file, song);
        }
        Console.WriteLine($"Playlist successfully saved to {file}");
    }
    static void Main(string[] args)
    {   
        string[] songs = loadSongs("songs.csv");
        int len = songs.Length;
        bool running = true;
        int playlistCnt = 1, playlistLength;

        List<string> newPlaylist = new List<string>();
        Random rd = new Random();

         if (File.Exists("playlist.csv")) {
                File.Delete("playlist.csv");
        }

        Console.WriteLine("Random Music Playlist\n----------------------");

        while (running) {
            newPlaylist.Clear();
            
            while (true) {
                Console.WriteLine("Enter the number of songs to add: ");
                playlistLength = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Generating...");
                newPlaylist.Add($"Playlist {playlistCnt}\n");
                if (1<=playlistLength && playlistLength<=len) {
                    for (int n=1; n<=playlistLength; n++) {
                        int rn = rd.Next(0, len);
                        string song = songs[rn];
                        if (!newPlaylist.Contains(song)) {
                            newPlaylist.Add(song);
                        } else {
                            n--;
                        }  
                    }
                    newPlaylist.Add("-------------------\n");
                    savePlaylist(newPlaylist, "playlist.csv");
                    playlistCnt++;
                    break;
                } else {
                    Console.WriteLine($"ERROR: Please enter a number between 1-{len}");
                }
            }
            
            
            Console.WriteLine("Would you like to continue? (y/n) ");
            if (Console.ReadLine().ToUpper() == "N") {
                running = false;
            } 
        
        }
    }
}
